Silk companion icon set #1 - "More Silk!"
Last updated: 19 November 2007

_________________________________________
Damien Guard
http://www.damieng.com/icons/silkcompanion
_________________________________________

This work is licensed under a
Creative Commons Attribution 2.5 License.
[ http://creativecommons.org/licenses/by/2.5/ ]

The FamFamFam Silk icon set is a very large,
consistent set of well-drawn icons that has
proven to be popular with both applications
and web sites.

On a number of occasions I have found myself
wanting more icons in the same style. This 
companion set represents what I needed but also
what I felt like adding.

Some are new icons in the same style, some are
alternative sizes/colours of the existing icons
and some are new compositions of the elements.

Any questions about this companion set please
contact damieng@gmail.com.



The Original Silk readme this work is based upon:


Silk icon set 1.3

_________________________________________
Mark James
http://www.famfamfam.com/lab/icons/silk/
_________________________________________

This work is licensed under a
Creative Commons Attribution 2.5 License.
[ http://creativecommons.org/licenses/by/2.5/ ]

This means you may use it for any purpose,
and make any changes you like.
All I ask is that you include a link back
to this page in your credits.

Are you using this icon set? Send me an email
(including a link or picture if available) to
mjames@gmail.com

Any other questions about this icon set please
contact mjames@gmail.com